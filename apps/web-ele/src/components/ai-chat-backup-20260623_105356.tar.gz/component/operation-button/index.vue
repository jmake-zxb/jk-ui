<template>
  <div class="operation-button-container">
    <ShareOperationButton v-if="type === 'share'" v-bind:data="chatRecord" />

    <LogOperationButton
      v-else-if="type === 'log'"
      v-bind:data="chatRecord"
      @update:data="(event: any) => emit('update:chatRecord', event)"
      :applicationId="application.id"
      :tts="application.tts_model_enable"
      :tts_type="application.tts_type"
      :type="type"
    />

    <div class="mt-8" v-else>
      <el-button
        type="primary"
        v-if="chatRecord.is_stop && !chatRecord.write_ed"
        @click="startChat(chatRecord)"
        link
        >{{ $$t('aiChat.operation.continue') }}
      </el-button>
      <!-- <el-button type="primary" v-else-if="!chatRecord.write_ed" @click="stopChat(chatRecord)" link
        >{{ $$t('aiChat.operation.stopChat') }}
      </el-button> -->
    </div>

    <ChatOperationButton
      v-show="chatRecord.write_ed && 500 != chatRecord.status"
      :tts="application.tts_model_enable"
      :tts_type="application.tts_type"
      :tts_autoplay="application.tts_autoplay"
      :data="chatRecord"
      :type="type"
      :applicationId="application.id"
      :chatId="chatRecord.chat_id"
      :chat_loading="loading"
      @regeneration="regenerationChart(chatRecord)"
    />
  </div>
</template>
<script setup lang="ts">
import { ElAvatar, ElButton, ElButtonGroup, ElCard, ElCheckTag, ElCheckbox, ElCheckboxGroup, ElCol, ElDialog, ElDivider, ElDrawer, ElDropdown, ElDropdownItem, ElDropdownMenu, ElForm, ElFormItem, ElIcon, ElImage, ElInput, ElOption, ElPopover, ElRow, ElScrollbar, ElSelect, ElSpace, ElText, ElTooltip, ElUpload, ElCollapse, ElCollapseItem } from 'element-plus'
import ChatOperationButton from '#/components/ai-chat/component/operation-button/ChatOperationButton.vue'
import LogOperationButton from '#/components/ai-chat/component/operation-button/LogOperationButton.vue'
import ShareOperationButton from '#/components/ai-chat/component/operation-button/ShareOperationButton.vue'
import { type chatType } from '#/api/ai/types'
defineProps<{
  type: 'log' | 'ai-chat' | 'debug-ai-chat' | 'share'
  chatRecord: chatType
  application: any
  loading: boolean
  startChat: (chat_record: any) => void
  stopChat: (chat_record: any) => void
  regenerationChart: (chat_record: any) => void
}>()
const emit = defineEmits(['update:chatRecord'])
</script>
<style lang="scss" scoped></style>
