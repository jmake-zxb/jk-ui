<template>
  <el-dropdown
    v-if="isOpen"
    trigger="contextmenu"
    :teleported="false"
    :style="{
      position: 'fixed',
      left: menuPosition.x + 'px',
      top: menuPosition.y + 'px',
      zIndex: 9999,
    }"
    @visible-change="handleVisibleChange"
  >
    <span style="display: none"></span>
    <template #dropdown>
      <el-dropdown-menu>
        <el-dropdown-item
          v-for="(menu, index) in menus"
          :key="index"
          @click="menu.click"
        >
          {{ menu.label }}
        </el-dropdown-item>
      </el-dropdown-menu>
    </template>
  </el-dropdown>
</template>

<script setup lang="ts">
import { ElAvatar, ElButton, ElButtonGroup, ElCard, ElCheckTag, ElCheckbox, ElCheckboxGroup, ElCol, ElDialog, ElDivider, ElDrawer, ElDropdown, ElDropdownItem, ElDropdownMenu, ElForm, ElFormItem, ElIcon, ElImage, ElInput, ElOption, ElPopover, ElRow, ElScrollbar, ElSelect, ElSpace, ElText, ElTooltip, ElUpload, ElCollapse, ElCollapseItem } from 'element-plus'
import bus from '#/utils/bus'
import { ref, nextTick, onMounted } from 'vue'
import { $t } from '#/locales'

const isOpen = ref<boolean>(false)
const menuPosition = ref({ x: 0, y: 0 })

function getSelection() {
  const selection = window.getSelection()
  if (selection) {
    if (selection.rangeCount === 0) return undefined
    const range = selection.getRangeAt(0)
    const fragment = range.cloneContents()
    const div = document.createElement('div')
    div.appendChild(fragment)
    if (div.textContent) {
      return div.textContent.trim()
    }
  }
  return undefined
}

/**
 * 打开控制台
 * @param event
 */
const openControl = (event: any) => {
  const c = getSelection()
  if (c) {
    menuPosition.value = { x: event.clientX, y: event.clientY }
    if (!isOpen.value) {
      nextTick(() => {
        isOpen.value = true
      })
    } else {
      clearSelectedText()
      isOpen.value = false
    }
    event.preventDefault()
  } else {
    isOpen.value = false
  }
}

const menus = ref([
  {
    label: $t('common.copy'),
    click: () => {
      const selectionText = getSelection()
      if (selectionText) {
        clearSelectedText()
        if (
          typeof navigator.clipboard === 'undefined' ||
          typeof navigator.clipboard.writeText === 'undefined'
        ) {
          const input = document.createElement('input')
          input.setAttribute('value', selectionText)
          document.body.appendChild(input)
          input.select()
          try {
            if (document.execCommand('copy')) {
              ElMessage.success($t('common.copySuccess'))
            }
          } finally {
            document.body.removeChild(input)
          }
        } else {
          navigator.clipboard.writeText(selectionText).then(() => {
            ElMessage.success($t('common.copySuccess'))
          })
        }
      }
      isOpen.value = false
    },
  },
  {
    label: $t('aiChat.quote'),
    click: () => {
      bus.emit('chat-input', getSelection())
      clearSelectedText()
      isOpen.value = false
    },
  },
])

/**
 * 清除选中文本
 */
const clearSelectedText = () => {
  if (window.getSelection) {
    const selection = window.getSelection()
    if (selection) {
      selection.removeAllRanges()
    }
  }
}

const handleVisibleChange = (visible: boolean) => {
  if (!visible) {
    isOpen.value = false
  }
}

onMounted(() => {
  bus.on('open-control', openControl)
})
</script>

<style lang="scss" scoped>
.el-dropdown {
  pointer-events: none;
}
</style>
